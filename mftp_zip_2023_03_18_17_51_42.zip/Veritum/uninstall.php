<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$items = get_posts(
    [
        'post_type'   => 'Fundrising',
        'post_status' => 'any',
        'numberposts' => - 1,
        'fields'      => 'ids',
    ]
);

if ( $items ) {
    foreach ( $items as $item ) {
        wp_delete_post( $item->ID, true );
    }
}
