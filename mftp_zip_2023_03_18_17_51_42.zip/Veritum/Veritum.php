<?php
/**
 * Plugin Name: Veritum - Donation Plugin
 * Description: The most robust, flexible, and intuitive way to accept donations on WordPress.
 * Author: theSnikk
 * Author URI: https://t.me/theSnikk
 * Version: 1.0
 * Requires at least: 5.0
 * Requires PHP: 7.0
 * Text Domain: Veritum
 */

if (!defined('ABSPATH')) {
    exit;
}
// include("stripe/init.php");
$plugin_url = plugin_dir_url( __FILE__ );

include 'default_terms.php';

global $fund_type;
global $fund_state;
global $tags;
global $menu_tags;

require_once(__DIR__ . '/stripe-php-9.6.0/init.php');

class Veritum{
    public $stripe;
    public $fund_types;
    public $fund_states;
    public $tags;
    public $menu_tags;
    function __construct(){
        global $fund_type;
        global $fund_state;
        global $tags;
        global $menu_tags;
        $this->fund_types = $fund_type;
        $this->fund_states = $fund_state;
        $this->tags = $tags;
        $this->menu_tags = $menu_tags;
        if (get_option('veritum_settings') != FALSE)
        {
            $veritum_options = get_option('veritum_settings');
            if(false === ($this->stripe = get_transient('stripe'))){
                $this->stripe = new \Stripe\StripeClient($veritum_options['private_key']);
                set_transient('stripe', $this->stripe, 12 * HOUR_IN_SECONDS);
            }
        }

        add_action( 'init', [$this,'my_post_type'] );
        add_action( 'init', [ $this, 'add_tag_terms']);
        register_activation_hook( __FILE__, [$this, 'activation'] );
        register_deactivation_hook( __FILE__, [$this, 'deactivation'] );
        add_action( 'wp_enqueue_scripts', [$this, 'utm_user_scripts'] );
        add_action( 'admin_enqueue_scripts',[$this,'enqueue_admin'] );
        add_action( "admin_init", [$this,"add_post_meta_boxes"] );
        add_action( 'save_post', [$this,'save_post_meta_boxes'] );
        add_action( 'save_post', [$this,'new_fundrising']);
        add_action( 'admin_menu', [ $this, 'add_admin_menu' ], 9);
        add_action( 'admin_init', [ $this, 'register_settings']);

        add_filter('template_include', [$this,'my_post_template']);
        add_filter('template_include', [$this,'my_tax_template']);
    }

   
    function activation (){
        $this->my_post_type();
        flush_rewrite_rules();
    }

    function my_post_type(){
        register_post_type('fundrising', array(
            'label' => esc_html__('Сборы', 'Veritum'),
            'has_archive' => true,
            'rewrite' => ['slug'=>'Сборы'],
            'public' => true,
            'supports' => array('title', 'editor' ,'thumbnail'),
            'menu_position' => 3
        ));

        $labels = array(
            'name'              => _x( 'Тип сборов', 'taxonomy general name', 'Veritum' ),
            'singular_name'     => _x( 'fund_type', 'taxonomy singular name', 'Veritum' ),
            'search_items'      => __( 'Search fund_types', 'Veritum' ),
            'all_items'         => __( 'All fund_types', 'Veritum' ),
            'parent_item'       => __( 'Родительский тип сборов', 'Veritum' ),
            'parent_item_colon' => __( 'Parent fund_type:', 'Veritum' ),
            'edit_item'         => __( 'Edit fund_type', 'Veritum' ),
            'update_item'       => __( 'Update fund_type', 'Veritum' ),
            'add_new_item'      => __( 'Добавить тип сборов', 'Veritum' ),
            'new_item_name'     => __( 'New fund_type Name', 'Veritum' ),
            'menu_name'         => __( 'Тип сборов', 'Veritum' ),
        );

        $args_type = array(
            'hierarchical'      => true,
            'labels'            => $labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => array( 'slug' => 'fundrising-type' ),
        );

        register_taxonomy('fund_type','fundrising',$args_type);

        $labels = array(
            'name'              => _x( 'Состояние сборов', 'taxonomy general name', 'Veritum' ),
            'singular_name'     => _x( 'Состояние сбора', 'taxonomy singular name', 'Veritum' ),
            'search_items'      => __( 'Search fund_state', 'Veritum' ),
            'all_items'         => __( 'Все Состояние сборов', 'Veritum' ),
            'parent_item'       => __( 'Родительское состояние сборов', 'Veritum' ),
            'parent_item_colon' => __( 'Родительское состояние сборов:', 'Veritum' ),
            'edit_item'         => __( 'Редактировать состояние сборов', 'Veritum' ),
            'update_item'       => __( 'Обновить состояние сборов', 'Veritum' ),
            'add_new_item'      => __( 'Добавить состояние сборов', 'Veritum' ),
            'new_item_name'     => __( 'Новое состояние сборов', 'Veritum' ),
            'menu_name'         => __( 'Состояние сборов', 'Veritum' ),
        );

        $args_type = array(
            'hierarchical'      => true,
            'labels'            => $labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => array( 'slug' => 'fundrising-state' ),
        );

        register_taxonomy('fund_state','fundrising',$args_type);

        $args_type = array(
            'hierarchical'      => true,
            'show_ui'           => false,
            'show_admin_column' => false,
            'query_var'         => false,
            'public'            => false,
            'show_in_quick_edit'=> false,
            'meta_box_cb'       => false,
        );

        register_taxonomy('tags','post',$args_type);
        register_taxonomy_for_object_type( 'category', 'attachment' );
    }


    function add_tag_terms(){
        foreach($this->tags as $tag){
            wp_insert_term(
                $tag,   // the term 
                'tags' // the taxonomy
            );
        }
    }

    static function deactivation (){
        unregister_taxonomy('fund_type');
        unregister_taxonomy('fund_state');
        unregister_post_type( 'fundrising' );

        flush_rewrite_rules();
    }
    
    function add_admin_menu(){
        add_menu_page( 
            'Veritum', 
            'Veritum', 
            'manage_options', 
            'veritum_menue', 
            [$this, 'admin_menu_html'], 
            'dashicons-heart', 
            2 
        );
        add_submenu_page( 
            'veritum_menue', 
            'contacts', 
            'Наши контакты', 
            'manage_options', 
            'contacts', 
            [$this, 'contacts_menu_html']
        );
    }

    function  admin_menu_html(){
        require_once plugin_dir_path(__FILE__).'templates/admin.php';
    }

    function  contacts_menu_html(){
        require_once plugin_dir_path(__FILE__).'templates/contacts.php';
    }


    function register_settings() {
        // creates our settings in the options table
        register_setting('veritum_settings_group', 'veritum_settings');

        add_settings_section('veritum_settings_section', '', null, 'veritum_menue');
        add_settings_field('public_key', 'Публичный ключ Stripe:', [$this, 'public_key_html'], 'veritum_menue', 'veritum_settings_section');
        add_settings_field('private_key', 'Приватный ключ Stripe:', [$this, 'private_key_html'], 'veritum_menue', 'veritum_settings_section');

        register_setting('contacts_settings_group', 'contacts_settings');
        register_setting('contacts_settings_group', 'add_contacts');

        add_option( 'contact_slugs', ['Twitter','Facebook','Telegram','Youtube','Instagram','Mail'] );
 
        add_settings_section('contacts_settings_section', '', null, 'contacts');
          
        $contact_options = get_option('contact_slugs');
        foreach($contact_options as $option){
            add_settings_field($option, $option.':', [$this, 'contact_field_html'], 'contacts', 'contacts_settings_section', [$option]);               
        }

        add_settings_field('add_contact_field', 'Добавить:', [$this, 'add_contact_html'], 'contacts', 'contacts_settings_section');
        add_settings_field('remove_contact_field', 'Удалить:', [$this, 'remove_contact_html'], 'contacts', 'contacts_settings_section');
    }

    function public_key_html(){
        $options = get_option('veritum_settings'); 
        ?>
        <input class="stripe-imput" type="text" name="veritum_settings[public_key]"
            value="<?php echo isset($options['public_key']) ? $options['public_key'] : "";  ?>" />
        <?php
    }

    function private_key_html(){
        $options = get_option('veritum_settings'); 
        ?>
        <input class="stripe-imput" type="text" name="veritum_settings[private_key]"
            value="<?php echo isset($options['private_key']) ? $options['private_key'] : "";  ?>" />
        <?php
    }

    function add_contact_html(){
        $options = get_option('add_contacts');
        $contact_slugs = get_option('contact_slugs');
        if(isset($options['add_contact']) && !$options['add_contact'] == "" && !in_array($options['add_contact'], $contact_slugs)){
            array_push($contact_slugs, $options['add_contact']);
            update_option( 'contact_slugs', $contact_slugs );
        }
        ?>
        
        <input class="stripe-imput" type="text" name="add_contacts[add_contact]" value="<?php echo isset($options['add_contact']) ? $options['add_contact'] : "";  ?>" />
        
        <?php
    }

    function remove_contact_html(){
        $contact_slugs = get_option('contact_slugs');
        $contacts_settings = get_option('contacts_settings');
        $options = get_option('add_contacts');
        if(isset($options['remove_contact'])){
            unset($contacts_settings[$options['remove_contact']]);
            $contact_slugs = array_diff($contact_slugs, [$options['remove_contact']]);
            update_option('contacts_settings', $contacts_settings);
            update_option('contact_slugs', $contact_slugs);
        }
        ?>
        
        <input class="stripe-imput" type="text" name="add_contacts[remove_contact]" value="<?php echo isset($options['remove_contact']) ? $options['remove_contact'] : "";  ?>" />
        
        <?php
    }

    function contact_field_html($contact_slug){
        $options = get_option('contacts_settings');
    ?>
        <input class="stripe-imput" type="text" name="contacts_settings[<?php echo $contact_slug[0]?>][0]"
            value="<?php echo isset($options[$contact_slug[0]][0]) ? $options[$contact_slug[0]][0] : "";  ?>" />
        
        <input class="checkbox1" type="checkbox" name="contacts_settings[<?php echo $contact_slug[0]?>][1]" value="1"
            <?php checked(1, $options[$contact_slug[0]][1], true); ?> />
        <input class="checkbox2" type="hidden" name="contacts_settings[<?php echo $contact_slug[0]?>][1]" value="0" />
        
        <input type="hidden" name="contacts_settings[<?php echo $contact_slug[0]?>][2]"
        value="<?php echo $options[$contact_slug[0]][2] = $contact_slug[0];?>" />
    <?php
    }

    function add_post_meta_boxes() { 
        add_meta_box(
            "fundrising_goals", // div id containing rendered fields
            "Цель сбора", // section heading displayed as text
            [$this, "goals_meta_box_html"], // callback function to render fields
            "fundrising", // name of post type on which to render fields
            "side", // location on the screen
            "low" // placement priority
        );

        add_meta_box(
            "stripe_product", // div id containing rendered fields
            "Ключь продукта", // section heading displayed as text
            [$this, "product_meta_box_html"], // callback function to render fields
            "fundrising", // name of post type on which to render fields
            "side", // location on the screen
            "low" // placement priority
        );
        
    }

    function save_post_meta_boxes($post_id){
        // global $post;
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }
        if(isset($_POST['amount']) && isset($_POST['goal']) ){
            $amount      = sanitize_text_field( $_POST[ "amount" ] );
            $goal        = sanitize_text_field( $_POST[ "goal" ] );
            $productKey  = sanitize_text_field( $_POST[ "productKey" ] );

            update_post_meta( $post_id, "fundrising_goals", [$amount,  $goal] );
            update_post_meta( $post_id, "stripe_product_key", $productKey );
        }

    }

    function goals_meta_box_html(){
        if (!empty(get_post_meta(get_the_ID(), 'fundrising_goals', false))){
            $goals      = get_post_meta(get_the_ID(), 'fundrising_goals', false);
            $amount     = $goals[0][0];
            $goal       = $goals[0][1];

        ?>
        <form action="" method="POST" name="fundrising_goals" id="fundrising_goals">
            <label for="amount">Собрано:</label>
            <br>
            <?php echo '<input type="number" name="amount" id="amount" value="'.$amount.'">' ?>
            <br>
            <label for="goal">Цель собора:</label>
            <br>
            <?php echo '<input type="number" name="goal" id="goal" value="'.$goal.'">' ?>
        </form>
        <?php
        }else{
        ?>
        <form action="" method="POST" name="fundrising_goals" id="fundrising_goals">
            <label for="amount">Собрано:</label>
            <br>
            <?php echo '<input type="number" name="amount" id="amount">' ?>
            <br>
            <label for="goal">Цель собора:</label>
            <br>
            <?php echo '<input type="number" name="goal" id="goal">' ?>
        </form>
        <?php
                }
                
            }

    public function product_meta_box_html(){
        if(!empty(get_post_meta(get_the_ID(), 'stripe_product_key', false))){
            $productKey = get_post_meta(get_the_ID(), 'stripe_product_key', false);       
            echo '<input type="text" method="POST" name="productKey" id="productKey" value="'.$productKey[0].'">';
        }else{
            $product = $this->stripe->products->create([
                'name' => get_the_title(),
            ]);
            $productKey = $product['id'];
            update_post_meta( get_the_ID(), "stripe_product_key", $productKey );
        }
    }

    public function new_fundrising(){
        if(empty(get_post_meta(get_the_ID(), 'stripe_product_key', false)[0]) && !empty(get_the_title())){
            $product = $this->stripe->products->create([
                'name' => get_the_title(),
            ]);
            $productKey = $product['id'];
            update_post_meta( get_the_ID(), "stripe_product_key", $productKey );
        }
    }

    public function my_post_template($template){

        if(is_singular('fundrising')){
            $theme_files = ['fundrising.php','Veritum/fundrising.php'];
            $exist = locate_template( $theme_files, false);
            if($exist != ''){
                return $exist;
            } else {
                return plugin_dir_path(__FILE__).'templates/fundrising.php';
            }
        }
        return $template;
    }

    public function my_tax_template($template){

        if(is_tax('fund_type')){
            $theme_files = ['fundrising-type.php','Veritum/fundrising-type.php'];
            $exist = locate_template( $theme_files, false);
            if($exist != ''){
                return $exist;
            } else {
                return plugin_dir_path(__FILE__).'templates/fundrising-type.php';
            }
        }
        return $template;
    }


function utm_user_scripts() {
    $plugin_url = plugin_dir_url( __FILE__ );
    wp_enqueue_style('veritum_reset',  $plugin_url . "assets/reset.css");
    wp_enqueue_style('preconnect','https://fonts.googleapis.com' );
    wp_enqueue_style('preconnect1','https://fonts.gstatic.com' );
    wp_enqueue_style('fonts','https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700;900&display=swap' );
    wp_enqueue_style('veritum_front', $plugin_url."/assets/front/style.css"); 
    wp_enqueue_script('veritum_front_s', $plugin_url."/assets/front/scripts.js");
    wp_enqueue_script('stripe_s', "https://js.stripe.com/v3/");
}

public function enqueue_admin(){
    $plugin_url = plugin_dir_url( __FILE__ );
    wp_enqueue_style ('veritum_back',  $plugin_url . "assets/back/style.css");
}


// function init_stripe(){
//     $stripe = new \Stripe\StripeClient('sk_test_51Lhj7XEDEruuUbKLr361xU7IAKABCj6FLQ8IKrtRNs4q3HcTgioQ5gK1OEDNQ3njvcWzhJuo2jpUXsDMW4eEzri600kdS1ZOdR');
// }
}

$veritum =  new Veritum;