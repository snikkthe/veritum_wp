<h1>Наши контакты</h1>
<?php 
    settings_errors(); 
?>
<div class="container">
    <form id="conacts_form" method="post" action="options.php">
        <?php 
            settings_fields('contacts_settings_group');
            do_settings_sections('contacts');
            submit_button();
        ?>
    </form>
</div>
<script>
    var form = document.getElementById("conacts_form");
    var imputs1 = form.getElementsByClassName("checkbox1");
    var imputs2 = form.getElementsByClassName("checkbox2");
    
    form.addEventListener('submit', () => {
        for (let index = 0; index < imputs1.length; ++index) {
            if(imputs1[index].checked) {
                imputs2[index].disabled = true;
            }
        }
    });
</script>