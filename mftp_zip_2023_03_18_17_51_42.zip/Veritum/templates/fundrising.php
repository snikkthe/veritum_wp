<?php
get_header('menu'); 

the_post();
$instance = new Veritum();
$instance ->activation();

$veritum_options = get_option('veritum_settings');

if(false === ($stripe = get_transient('stripe'))){
	$stripe = new \Stripe\StripeClient($veritum_options['private_key']);
	set_transient('stripe', $stripe, 12 * HOUR_IN_SECONDS);
}else{
	$stripe = get_transient('stripe');
}

$postID 	= get_the_ID();
$term		= get_the_terms( $postID, 'fund_type' );
update_post_meta( get_the_ID(), "update", false );

$url 		= "https://";
$url		.= $_SERVER['HTTP_HOST'];      
$url		.= $_SERVER['REQUEST_URI'];
$parse 		= parse_url($url, PHP_URL_QUERY);
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}

$ipdat = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));
$country = $ipdat->geoplugin_countryCode;
if(!empty($parse)){
	$checout_id = substr($parse,11);
	$checout 	= $stripe->checkout->sessions->retrieve ($checout_id, []);
	if($checout->status == 'complete'){
		$meta	= get_post_meta($postID, 'fundrising_goals', false)[0][0];
		$amount = get_post_meta($postID, 'fundrising_goals', false)[0][2];
		$amount+=$meta;
		$goal	= get_post_meta($postID, 'fundrising_goals', false)[0][1];
		update_post_meta( get_the_ID(), "fundrising_goals", [$amount,  $goal, 0] );
		if(get_post_meta($postID, 'fundrising_goals', false)[0][0] >= get_post_meta($postID, 'fundrising_goals', false)[0][1]*0.9){
			wp_set_object_terms( $postID, 29, 'fund_state' );
		}
		if(get_post_meta($postID, 'fundrising_goals', false)[0][0] >= get_post_meta($postID, 'fundrising_goals', false)[0][1]){
			wp_set_object_terms( $postID, 27, 'fund_state' );
		}
		echo '<span>' .get_post_meta(get_the_ID(), 'fundrising_goals', false)[0][0].'</span>';
	}

}

$goals	= get_post_meta($postID, 'fundrising_goals', false);

$categories = get_terms( ['taxonomy' => 'tags','orderby' => 'name', 'order' => 'ASC', 'hide_empty' => false,] );
$stack = [];
foreach( $categories as $category ) {
    array_push($stack, $category->name);
}

$args = array("post_type" => "post", 'name' =>"Поддержи команду");
$query = get_posts( $args );

?>

<body>
	<div class="container">
	<?php if ($term[0]->slug == "main"){ ?>
		<a class="category_link" href=<?php echo get_term_link( $term[1] );?> >
			<?php echo 'Вернуться к ' . $term[1]->name;?>
		</a>
	<?php
	}else{
	?>
		<a class="category_link" href=<?php echo get_term_link( $term[0] );?> >
			<?php echo 'Вернуться к ' . $term[0]->name;?>
		</a>
	<?php
	}
	?>
		<h2 class="head2">       		
			<?php  the_title(); ?>
		</h2>
		<div class="fundrising">
			<div class="fundrising__img-wrap">
				<img class = "fundrising-img" src="<?php echo get_the_post_thumbnail_url()?>">  
			</div>
			<div class="fundrising__form-wrap">
				<form class="fundrising__form" action="" method="POST" id ="peyment-form">
						<div class="fundrising__block">
							<div class="fundrising__row --goals">
								<?php echo $stack[12];?>
								<h4>
									<?php echo '€ '. $goals[0][0] .' из '. $goals[0][1] ?> 
								</h4>
							</div> 
							<?php echo '<progress class="progress__bar" value="'.$goals[0][0].'" max="'.$goals[0][1].'"></progress>' ?>
						</div>
						<div class="fundrising__block">
							<div class="fundrising__row">
							<select class="form-select --currency" name="currency"> 
								<option value="USD">$ Доллар</option>
								<option value="EUR" selected>€ Евро</option>
								<option value="UAH">₴ Гривня</option>
							</select>
							<input class="form-select --amount" min="0" type="number" name="amount-imp">
						</div>
						<p class="l3 minimum --hiden">minimum: 200</p>
						</div>
						<div class="fundrising__block">
							<p class="l1"><?php echo $query[0]->name ; ?><br></p>
							<p class="l2">
								<?php echo $form_content; ?> <br>
							</p>
						</div>
						<div class="fundrising__block">
							<select class="form-select --team" name="team-amount"> 
								<option value="0">0%</option>
								<option value="0.01">1%</option>
								<option selected value="0.05">5%</option>
								<option value="0.1">10%</option>
								<option value="0.15">15%</option>
								<option value="0.2">20%</option>
								<option value="0.25">25%</option>
								<option value="0.3">30%</option>
							</select>
						</div>
						<div class="fundrising__block">
							<div class="form-output">
								<p class="l2"><?php echo $stack[0];?> </p>
								<output name="amount-outp" class="l2"></output>
							</div>
							<div class="form-output">
								<p class="l2"><?php echo $stack[8];?></p>
								<output name="team-amount-outp" class="l2"></output>
							</div>
							<div class="form-output">
								<p class="l1"><?php echo $stack[5];?></p>
								<output name="total" class="l1"></output>
							</div>
						</div> 
						<div class="fundrising__row">
							<input type="submit" name="submit" class="submit"> 
						</div> 
					</form>
			</div>
		</div>
		<div class="tytel-wrap">
			<p class="tytel">
				<?php echo $stack[4];?>
			</p>
		</div>
		<div class="content-wrap">
			<?php the_content();?>
		</div>

		<?php echo '<span style="display: none" id ="Country" >' .$country.'</span>';?>

		<?php
		function thmx_currency_convert($amount, $cur){
			$url = 'https://api.exchangerate-api.com/v4/latest/'.$cur;
			$json = file_get_contents($url);
			$exp = json_decode($json);
			
			$convert = $exp->rates->EUR;
			
			return $convert * $amount;
		}

		if ($_SERVER["REQUEST_METHOD"] == "POST") {
			// collect value of input field
			$currency	= $_POST ['currency'];
			$amount   	= $_POST['amount-imp'];
			$team		= $_POST ['team-amount'];
			$total 		= (float) $amount + (float)$amount*(float)$team;
			$total		= $total*100;
			$permalink	= wp_sanitize_redirect(get_the_permalink());
			$productKey = get_post_meta(get_the_ID(), 'stripe_product_key', false);
			$goals		= get_post_meta($postID, 'fundrising_goals', false)[0];

			update_post_meta( get_the_ID(), "fundrising_goals", [$goals[0],  $goals[1], thmx_currency_convert($amount, $currency)] );
			
			if (!empty($amount)) {
				$checout =  $stripe->checkout->sessions->create([
					'success_url' 			=> $permalink.'?session_id={CHECKOUT_SESSION_ID}',
					'cancel_url' 			=> $permalink,
					'payment_method_types'	=> ['card'],
					'line_items' => [
					[
						'price_data' => [
							'product'		=> $productKey[0],
							'currency' 	  	=> $currency, 
							'unit_amount' 	=> $total
						],
						'quantity' => 1,
					],
					],
					'mode' => 'payment',
				]);
				
			echo '<span id ="cecoutID" >' .$checout->id.'</span>';
		}
			
	}

	?>
	</div>

<script>
	const stripe = Stripe("<?php echo $veritum_options['public_key']?>");
	var id = document.querySelector("#cecoutID").innerHTML;
	stripe.redirectToCheckout ({ sessionId:id });
	console.log(id)
</script>
	
<script>
	var country = document.querySelector("#Country").innerHTML;
	let form = document.getElementById('peyment-form');
	let currency = form.elements["currency"];
	let team = form.elements["team-amount"];
	if (country = "UA"){
		currency.value = "UAH";
		team.value = "0.01"
	}else if (country = "US"){
		currency.value = "USD";
	} else{
		currency.value = "EUR";
	}
</script>
<script>
	let currency1 = form.elements["currency"].value;
	if(form.elements["currency"].value == "UAH"){
			document.querySelector(".minimum").classList.remove("--hiden");
	}
	form.elements["amount-imp"].addEventListener('change', (event) => {
		if(form.elements["currency"].value == "UAH" && form.elements["amount-imp"].value < 200 ){
			form.elements["amount-imp"].value = 200;
		}
		let   amount =  Number(form.elements["amount-imp"].value);
		let	  team = Math.round((amount * Number(form.elements["team-amount"].value))*100)/100;
		let	  total =amount + team ;
		form.elements["amount-outp"].value = amount;
		form.elements["team-amount-outp"].value = team;
		form.elements["total"].value = total;	
	});
	form.elements["team-amount"].addEventListener('change', (event) => {
		let   amount =  Number(form.elements["amount-imp"].value);
		let	  team = Math.round((amount * Number(form.elements["team-amount"].value))*100)/100;
		let	  total =amount + team ;
		form.elements["amount-outp"].value = amount;
		form.elements["team-amount-outp"].value = team;
		form.elements["total"].value = total;
	});
	form.elements["currency"].addEventListener('change', (event) => {
		if(form.elements["currency"].value == "UAH"){
			document.querySelector(".minimum").classList.remove("--hiden");
		}else{
			document.querySelector(".minimum").classList.add("--hiden");
		}
	});
    var uri = window.location.toString();
	console.log(uri.indexOf("?")>0);
    if(uri.indexOf("?")>0){
		document.querySelector(".fundrising__form").classList.add("--hiden");
		document.querySelector(".fundrising-sucess").classList.remove("--hiden");
        var clean_uri = uri.substring(uri, uri.indexOf("?"));
		console.log(clean_uri);
        window.history.replaceState({}, document.title, clean_uri);
	}
</script>

</body>

<?php
	get_footer();
?>