<h1>Ключи Stripe</h1>
<?php 
    settings_errors(); 
?>
<div class="container">
    <form method="post" action="options.php">
        <?php 
            settings_fields('veritum_settings_group');
            do_settings_sections('veritum_menue');
            submit_button();
        ?>
    </form>
</div>


