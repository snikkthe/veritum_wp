<?php

    $postID 	= get_the_ID();
    $term		= get_the_terms( $postID,'fund_type');
    $terms      = get_terms( [
        'taxonomy' => 'fund_state',
        'hide_empty' => false,
    ] );

    for($i = 0; $i < count($terms); $i++){
        for($j = 0; $j < count($terms); $j++){
            if(((int)$terms[$i]->description < (int)$terms[$j]->description)&&((int)$terms[$i]->description < 9)){
                $temp = $terms[$j];
                $terms[$j] = $terms[$i];
                $terms[$i] = $temp;
            }
        }
    }

    $categories = get_terms( ['taxonomy' => 'tags','orderby' => 'name', 'order' => 'ASC', 'hide_empty' => false,] );
    $stack = [];
    foreach( $categories as $category ) {
        array_push($stack, $category->name);
    }    
    
    get_header('menu'); 
?>

<div class="container">    
    <a class="category_link" href=<?php echo home_url();?> >
        <?php echo $stack[2];?>
    </a>
    
        <h2 class="catalogue__tytle"><?php echo $term[0]->name;?></h2>
       
        <div class="tabs">

            <div class="tabs__buttons" >
            <?php
                $i=0;
                foreach($terms as $term1 ){
                        if((int)$term1->description < 8 )
                        {
                    ?>
                    <button class="tabs__button" onclick="openTab(<?php echo $i;?>)">
                        <?php echo $term1->name ?>
                    </button>
            <?php
                        }
                    if((int)$term1->description < 8 ){
                        $i+=1;
                    }
                }
            ?>
            </div>
            <?php foreach($terms as $term1 ){
            ?>
            <div class="tabs__tabcontent">
                <div class="catalogue">
                    <div class="catalogue__items">
                    <?php

                        $args = [  
                            'post_type' => 'fundrising',
                            'posts_per_page' => -1,
                            'tax_query' => [
                                'relation' => 'AND',
                                [
                                    'taxonomy' => 'fund_type',
                                    'field' => 'slug',
                                    'terms' => $term[0]->slug,
                                ],
                                [
                                    'taxonomy' => 'fund_state',
                                    'field' => 'slug',
                                    'terms' =>  $term1->slug,
                                ],
                            ],
                        ];

                        $loop = new WP_Query( $args );
                        while ( $loop->have_posts() ) : $loop->the_post();
                        $goals	= get_post_meta(get_the_id(), 'fundrising_goals', false);
                    ?>
                        <div class="catalogu__card card">
                            <div class="card__img-wrap">
                                <a href="<?php the_permalink();?>">
                                    <?php echo '<img class="card__img" src="'.get_the_post_thumbnail_url(get_the_ID(),'full').'" alt="">';  ?>
                                </a>
                            </div>
                            <div class="card__content">
                                <a href="<?php the_permalink();?>">
                                    <h3 class="card__header">
                                        <?php the_title();?>
                                    </h3>
                                </a>
                                <div class="card__text">
                                    <?php the_excerpt()?>
                                </div>
                                <div class="card__progress progress">
                                    <div class="fundrising__row --goals">
                                        <?php echo $stack[12];?>
                                        <p>
                                            <?php echo '€ '. $goals[0][0] .' из '. $goals[0][1] ?> 
                                        </p>                        
                                    </div>
                                    <div class="progress-bar">
                                        <?php echo '<progress class="progress__bar" value="'.$goals[0][0].'" max="'.$goals[0][1].'"></progress>' ?> 
                                    </div>
                                </div>

                            </div>
                        </div>
                    <?php
                        endwhile;
                    ?>
                    </div>
                </div>
            </div>
            <?php 
            }
            ?>
        
        </div>
    

</div>

<?php
    get_footer();
?>


<script>
    var el = document.querySelector(".tabs__button");
    el.click();
</script>

