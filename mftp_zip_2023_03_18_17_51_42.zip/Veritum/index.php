<?php
//Silence is golden.